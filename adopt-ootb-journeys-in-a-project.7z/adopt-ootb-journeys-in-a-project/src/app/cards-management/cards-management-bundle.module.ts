import {NgModule} from "@angular/core";
import {
  CardsManagementJourneyModule,
  CardsManagementJourneyConfiguration,
  CardsManagementJourneyConfigurationToken,
} from "@backbase/cards-management-journey-ang";
import {TemplateRegistry} from "@backbase/foundation-ang/core";

@NgModule({
imports: [
  CardsManagementJourneyModule.forRoot()
],
  providers: [
    TemplateRegistry,
    {
      provide: CardsManagementJourneyConfigurationToken,
      useValue: <Partial<CardsManagementJourneyConfiguration>>{
        notificationTtl: 5000,
        groupByPaymentCardTypes: '',
        enableTravelNotice: false,
      },
    },
  ]
})
export class CardsManagementBundleModule {

}
